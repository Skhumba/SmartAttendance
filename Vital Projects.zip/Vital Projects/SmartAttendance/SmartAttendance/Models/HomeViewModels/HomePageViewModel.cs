﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Attendance.Domain;
using SmartAttendance.Controllers;

namespace SmartAttendance.Models.HomeViewModels
{
    public class HomePageViewModel
    {
        public IList<Faculty> Faculties { get; set; }
        public IList<Announcement> Announcements { get; set; }
        public string Description { get; set; }
    }
}
