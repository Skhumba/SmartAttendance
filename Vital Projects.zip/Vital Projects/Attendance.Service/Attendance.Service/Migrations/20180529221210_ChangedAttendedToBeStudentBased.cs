﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Attendance.Service.Migrations
{
    public partial class ChangedAttendedToBeStudentBased : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Attendies_Subjects_SubjectId",
                table: "Attendies");

            migrationBuilder.DropForeignKey(
                name: "FK_Students_Attendies_AttendedId",
                table: "Students");

            migrationBuilder.DropIndex(
                name: "IX_Students_AttendedId",
                table: "Students");

            migrationBuilder.DropColumn(
                name: "AttendedId",
                table: "Students");

            migrationBuilder.RenameColumn(
                name: "SubjectId",
                table: "Attendies",
                newName: "StudentId");

            migrationBuilder.RenameIndex(
                name: "IX_Attendies_SubjectId",
                table: "Attendies",
                newName: "IX_Attendies_StudentId");

            migrationBuilder.AddColumn<int>(
                name: "ScheduleId",
                table: "Attendies",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Attendies_ScheduleId",
                table: "Attendies",
                column: "ScheduleId");

            migrationBuilder.AddForeignKey(
                name: "FK_Attendies_Schedules_ScheduleId",
                table: "Attendies",
                column: "ScheduleId",
                principalTable: "Schedules",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Attendies_Students_StudentId",
                table: "Attendies",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Attendies_Schedules_ScheduleId",
                table: "Attendies");

            migrationBuilder.DropForeignKey(
                name: "FK_Attendies_Students_StudentId",
                table: "Attendies");

            migrationBuilder.DropIndex(
                name: "IX_Attendies_ScheduleId",
                table: "Attendies");

            migrationBuilder.DropColumn(
                name: "ScheduleId",
                table: "Attendies");

            migrationBuilder.RenameColumn(
                name: "StudentId",
                table: "Attendies",
                newName: "SubjectId");

            migrationBuilder.RenameIndex(
                name: "IX_Attendies_StudentId",
                table: "Attendies",
                newName: "IX_Attendies_SubjectId");

            migrationBuilder.AddColumn<int>(
                name: "AttendedId",
                table: "Students",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Students_AttendedId",
                table: "Students",
                column: "AttendedId");

            migrationBuilder.AddForeignKey(
                name: "FK_Attendies_Subjects_SubjectId",
                table: "Attendies",
                column: "SubjectId",
                principalTable: "Subjects",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Students_Attendies_AttendedId",
                table: "Students",
                column: "AttendedId",
                principalTable: "Attendies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
