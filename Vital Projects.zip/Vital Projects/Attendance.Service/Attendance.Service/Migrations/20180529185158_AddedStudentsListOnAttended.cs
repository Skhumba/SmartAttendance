﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Attendance.Service.Migrations
{
    public partial class AddedStudentsListOnAttended : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Attendies_Students_StudentId",
                table: "Attendies");

            migrationBuilder.DropIndex(
                name: "IX_Attendies_StudentId",
                table: "Attendies");

            migrationBuilder.DropColumn(
                name: "StudentId",
                table: "Attendies");

            migrationBuilder.AddColumn<int>(
                name: "AttendedId",
                table: "Students",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Students_AttendedId",
                table: "Students",
                column: "AttendedId");

            migrationBuilder.AddForeignKey(
                name: "FK_Students_Attendies_AttendedId",
                table: "Students",
                column: "AttendedId",
                principalTable: "Attendies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Students_Attendies_AttendedId",
                table: "Students");

            migrationBuilder.DropIndex(
                name: "IX_Students_AttendedId",
                table: "Students");

            migrationBuilder.DropColumn(
                name: "AttendedId",
                table: "Students");

            migrationBuilder.AddColumn<int>(
                name: "StudentId",
                table: "Attendies",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Attendies_StudentId",
                table: "Attendies",
                column: "StudentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Attendies_Students_StudentId",
                table: "Attendies",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
