﻿using System;
using System.Collections.Generic;
using System.Text;
using Attendance.Domain;

namespace Attendance.Service.Models.Data
{
    public interface IAttendanceService
    {
        #region Faculties
        
        List<Faculty> GetAllFaculties();
        Faculty GetFacultyById(int id);
        Faculty UpdateFaculty(int id, Faculty faculty);
        Faculty RemoveFaculty(int id);
        Faculty AddFaculty(Faculty faculty);

        #endregion

        #region Departments

        List<Department> GetAllDepartments();
        Department GetDepartmentById(int id);
        Department UpdateDepartment(int id, Department department);
        Department RemoveDepartment(int id);
        Department AddDepartment(Department department);

        #endregion

        #region Courses

        List<Course> GetAllCourses();
        Course GetCourseById(int id);
        Course UpdateCourse(int id, Course course);
        Course RemoveCourse(int id);
        Course AddCourse(Course course);

        #endregion

        #region Students

        List<Student> GetAllStudents();
        Student GetStudentById(int id);
        Student UpdateStudent(int id, Student student);
        Student RemoveStudent(int id);
        Student AddStudent(Student student);

        #endregion

        #region Lecturers

        List<Lecturer> GetAllLecturers();
        Lecturer GetLecturerById(int id);
        Lecturer UpdateLecturer(int id, Lecturer lecturer);
        Lecturer RemoveLecturer(int id);
        Lecturer AddLecturer(Lecturer lecturer);

        #endregion

    }
}
