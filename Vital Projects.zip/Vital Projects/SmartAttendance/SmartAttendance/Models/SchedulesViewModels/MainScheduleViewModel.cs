﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Attendance.Domain;

namespace SmartAttendance.Models.SchedulesViewModels
{
    public class MainScheduleViewModel
    {
        public Schedule Schedule { get; set; }
    }
}
