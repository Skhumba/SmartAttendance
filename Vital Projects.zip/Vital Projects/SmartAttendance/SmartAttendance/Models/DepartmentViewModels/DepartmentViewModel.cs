﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Attendance.Domain;

namespace SmartAttendance.Models.DepartmentViewModels
{
    public class DepartmentViewModel
    {
        public Department Department { get; set; }
        public string Description { get; set; }

        public IList<Announcement> Announcements { get; set; }
        public IList<Course> Courses { get; set; }
    }
}
