﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Attendance.Domain;
using Attendance.Service.Models.Data;

namespace Attendance.Service.Controllers
{
    [Produces("application/json")]
    [Route("api/Students")]
    public class StudentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        #region STUDENT CRUD OPERATIONS

        // GET: api/Students
        [HttpGet]
        public IEnumerable<Student> GetStudents()
        {
            return _context.Students;
        }

        // GET: api/Students/5
        [HttpGet("{id}/{includeSubjects}")]
        public async Task<IActionResult> GetStudent([FromRoute] int id, [FromRoute] bool includeSubjects)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var student = await _context.Students.SingleOrDefaultAsync(m => m.Id == id);

            if (student == null) { return NotFound(); }

            if (includeSubjects)
                student.EnrolledSubjects = _context.EnrolledSubjects.Include(es => es.Subject).Where(es => es.StudentId == id).ToList();

            return Ok(student);
        }

        // PUT: api/Students/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStudent([FromRoute] int id, [FromBody] Student student)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != student.Id)
            {
                return BadRequest();
            }

            student.LastUpdatedAt = DateTime.Now;

            _context.Entry(student).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Students
        [HttpPost]
        public async Task<IActionResult> PostStudent([FromBody] Student student)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            student.CreatedAt = DateTime.Now;
            student.LastUpdatedAt = DateTime.Now;

            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStudent", new { id = student.Id, includeSubjects = false }, student);
        }

        // DELETE: api/Students/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudent([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var student = await _context.Students.SingleOrDefaultAsync(m => m.Id == id);
            if (student == null)
            {
                return NotFound();
            }

            student.LastUpdatedAt = DateTime.Now;
            student.DeletedAt = DateTime.Now;
            student.IsDeleted = true;

            _context.Students.Remove(student);
            await _context.SaveChangesAsync();

            return Ok(student);
        }

        private bool StudentExists(int id)
        {
            return _context.Students.Any(e => e.Id == id);
        }



        #endregion

        #region ATTENDANCE REGISTER OPERATIONS

        public IActionResult GetAllEnrolledStudents(int subjectId)
        {
            var subject = _context.Subjects.FirstOrDefault(s => s.Id == subjectId);

            if(subject == null)
            {
                ModelState.AddModelError("Subject", "Subject with specified id was not found");
                return BadRequest(ModelState);
            }

            var students = _context.EnrolledSubjects.Include(es => es.Subject)
                                                    .Include(es => es.Student)
                                                    .Where(es => es.SubjectId == subjectId)
                                                    .Select(es => es.Student).AsEnumerable();

            return Ok(students);
        }

        #endregion

    }
}