﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Attendance.Service.Migrations
{
    public partial class AddedSensorIdOnStudent : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsCompleted",
                table: "Students");

            migrationBuilder.AddColumn<int>(
                name: "SensorId",
                table: "Students",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SensorId",
                table: "Students");

            migrationBuilder.AddColumn<bool>(
                name: "IsCompleted",
                table: "Students",
                nullable: false,
                defaultValue: false);
        }
    }
}
