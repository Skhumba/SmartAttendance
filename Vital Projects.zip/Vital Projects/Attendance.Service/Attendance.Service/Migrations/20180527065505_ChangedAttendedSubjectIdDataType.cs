﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Attendance.Service.Migrations
{
    public partial class ChangedAttendedSubjectIdDataType : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Attendies_Subjects_SubjectId1",
                table: "Attendies");

            migrationBuilder.DropIndex(
                name: "IX_Attendies_SubjectId1",
                table: "Attendies");

            migrationBuilder.DropColumn(
                name: "SubjectId1",
                table: "Attendies");

            migrationBuilder.AlterColumn<int>(
                name: "SubjectId",
                table: "Attendies",
                nullable: false,
                oldClrType: typeof(string));

            migrationBuilder.CreateIndex(
                name: "IX_Attendies_SubjectId",
                table: "Attendies",
                column: "SubjectId");

            migrationBuilder.AddForeignKey(
                name: "FK_Attendies_Subjects_SubjectId",
                table: "Attendies",
                column: "SubjectId",
                principalTable: "Subjects",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Attendies_Subjects_SubjectId",
                table: "Attendies");

            migrationBuilder.DropIndex(
                name: "IX_Attendies_SubjectId",
                table: "Attendies");

            migrationBuilder.AlterColumn<string>(
                name: "SubjectId",
                table: "Attendies",
                nullable: false,
                oldClrType: typeof(int));

            migrationBuilder.AddColumn<int>(
                name: "SubjectId1",
                table: "Attendies",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Attendies_SubjectId1",
                table: "Attendies",
                column: "SubjectId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Attendies_Subjects_SubjectId1",
                table: "Attendies",
                column: "SubjectId1",
                principalTable: "Subjects",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
