﻿using System.Collections.Generic;
using System.Linq;
using Attendance.Domain;

namespace Attendance.Service.Models.Data
{
    public class AttendanceService : IAttendanceService
    {
        private readonly ApplicationDbContext _applicationDbContext;

        public AttendanceService(ApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }

        public List<Faculty> GetAllFaculties()
        {
            return _applicationDbContext.Faculties.ToList();
        }

        public Faculty GetFacultyById(int id)
        {
            return _applicationDbContext.Faculties.FirstOrDefault(f => f.Id == id);
        }

        public Faculty UpdateFaculty(int id, Faculty faculty)
        {
            var existing = _applicationDbContext.Faculties.FirstOrDefault(f => f.Id == id);

            if(existing == null) return null;

            existing = faculty;

            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Faculty RemoveFaculty(int id)
        {
            var existing = _applicationDbContext.Faculties.FirstOrDefault(f => f.Id == id);

            if (existing == null)
                return null;

            _applicationDbContext.Faculties.Remove(existing);
            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Faculty AddFaculty(Faculty faculty)
        {
            _applicationDbContext.Faculties.Add(faculty);
            _applicationDbContext.SaveChanges();

            return faculty;
        }

        public List<Department> GetAllDepartments()
        {
            return _applicationDbContext.Departments.ToList();
        }

        public Department GetDepartmentById(int id)
        {
            return _applicationDbContext.Departments.FirstOrDefault(d => d.Id == id);
        }

        public Department UpdateDepartment(int id, Department department)
        {
            var existing = _applicationDbContext.Departments.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            existing = department;

            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Department RemoveDepartment(int id)
        {
            var existing = _applicationDbContext.Departments.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            _applicationDbContext.Departments.Remove(existing);
            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Department AddDepartment(Department department)
        {
            _applicationDbContext.Departments.Add(department);
            _applicationDbContext.SaveChanges();

            return department;
        }

        public List<Course> GetAllCourses()
        {
            return _applicationDbContext.Courses.ToList();
        }

        public Course GetCourseById(int id)
        {
            return _applicationDbContext.Courses.FirstOrDefault(c => c.Id == id);
        }

        public Course UpdateCourse(int id, Course course)
        {
            var existing = _applicationDbContext.Courses.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            existing = course;

            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Course RemoveCourse(int id)
        {
            var existing = _applicationDbContext.Courses.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            _applicationDbContext.Courses.Remove(existing);
            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Course AddCourse(Course course)
        {
            _applicationDbContext.Courses.Add(course);
            _applicationDbContext.SaveChanges(); 

            return course;
        }

        public List<Student> GetAllStudents()
        {
            return _applicationDbContext.Students.ToList();
        }

        public Student GetStudentById(int id)
        {
            return _applicationDbContext.Students.FirstOrDefault(s => s.Id == id);
        }

        public Student UpdateStudent(int id, Student student)
        {
            var existing = _applicationDbContext.Students.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            existing = student;

            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Student RemoveStudent(int id)
        {
            var existing = _applicationDbContext.Students.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            _applicationDbContext.Students.Remove(existing);
            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Student AddStudent(Student student)
        {
            _applicationDbContext.Students.Add(student);
            _applicationDbContext.SaveChanges();

            return student;
        }

        public List<Lecturer> GetAllLecturers()
        {
            return _applicationDbContext.Lecturers.ToList();
        }

        public Lecturer GetLecturerById(int id)
        {
            return _applicationDbContext.Lecturers.FirstOrDefault(a => a.Id == id);
        }

        public Lecturer UpdateLecturer(int id, Lecturer lecturer)
        {
            var existing = _applicationDbContext.Lecturers.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            existing = lecturer;

            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Lecturer RemoveLecturer(int id)
        {
            var existing = _applicationDbContext.Lecturers.FirstOrDefault(d => d.Id == id);

            if (existing == null)
                return null;

            _applicationDbContext.Lecturers.Remove(existing);
            _applicationDbContext.SaveChanges();

            return existing;
        }

        public Lecturer AddLecturer(Lecturer lecturer)
        {
            _applicationDbContext.Lecturers.Add(lecturer);
            _applicationDbContext.SaveChanges();

            return lecturer;
        }
    }
}
