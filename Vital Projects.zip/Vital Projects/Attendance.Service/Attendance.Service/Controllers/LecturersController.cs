﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Attendance.Domain;
using Attendance.Service.Models.Data;

namespace Attendance.Service.Controllers
{
    [Produces("application/json")]
    [Route("api/Lecturers")]
    public class LecturersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LecturersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Lecturers
        [HttpGet]
        public IEnumerable<Lecturer> GetLecturers()
        {
            return _context.Lecturers;
        }

        // GET: api/Lecturers/5
        //[HttpGet("{id}/{includeSubjects}")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetLecturer([FromRoute] int id)//, [FromRoute] bool includeSubjects)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Lecturer lecturer = null;            
            lecturer = await _context.Lecturers.SingleOrDefaultAsync(m => m.Id == id);
            if (lecturer == null)
            {
                return NotFound();
            }
            
            //if (includeSubjects)
            //    lecturer.Subjects = _context.Subjects.Where(s => s.LecturerId == id).ToList();

            return Ok(lecturer);
        }

        // PUT: api/Lecturers/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLecturer([FromRoute] int id, [FromBody] Lecturer lecturer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != lecturer.Id)
            {
                return BadRequest();
            }

            lecturer.LastUpdatedAt = DateTime.Now;

            _context.Entry(lecturer).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LecturerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Lecturers
        [HttpPost]
        public async Task<IActionResult> PostLecturer([FromBody] Lecturer lecturer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            lecturer.LastUpdatedAt = DateTime.Now;
            lecturer.CreatedAt = DateTime.Now;

            _context.Lecturers.Add(lecturer);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLecturer", new { id = lecturer.Id, includeSubjects = false }, lecturer);
        }

        // DELETE: api/Lecturers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLecturer([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var lecturer = await _context.Lecturers.SingleOrDefaultAsync(m => m.Id == id);
            if (lecturer == null)
            {
                return NotFound();
            }

            lecturer.IsDeleted = true;
            lecturer.DeletedAt = DateTime.Now;

            //_context.Lecturers.Remove(lecturer);
            await _context.SaveChangesAsync();

            return Ok(lecturer);
        }

        private bool LecturerExists(int id)
        {
            return _context.Lecturers.Any(e => e.Id == id);
        }
    }
}