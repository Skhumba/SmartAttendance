﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Attendance.Domain;
using Attendance.Service.Models.Data;

namespace Attendance.Service.Controllers
{
    [Produces("application/json")]
    [Route("api/Schedules")]
    public class SchedulesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SchedulesController(ApplicationDbContext context)
        {
            _context = context;
        }

        #region SCHEDULE CRUD OPERATIONS

        // GET: api/Schedules/confirmed
        [HttpGet("confirmed:bool")]
        public IEnumerable<Schedule> GetSchedules([FromRoute] bool confirmed = false)
        {
            if (confirmed)
                return _context.Schedules.Where(s => !s.IsDeleted && s.IsConfirmed);

            return _context.Schedules.Where(s => !s.IsDeleted);
        }

        // GET: api/Schedules/5
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetSchedule([FromRoute] int id)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var schedule = await _context.Schedules.SingleOrDefaultAsync(m => m.Id == id);

            if (schedule == null)
                return NotFound();

            return Ok(schedule);
        }

        /*
        // GET: api/Schedules/5/false               [  This will be used to confirm a schedule  ]
        [HttpGet("{id}/{confirm}")]
        public async Task<IActionResult> GetSchedule([FromRoute] int id, [FromRoute] bool confirm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var schedule = await _context.Schedules.SingleOrDefaultAsync(m => m.Id == id);

            if (schedule == null)
            {
                return NotFound();
            }

            if (schedule.SubjectId > 0)
            {
                if (confirm)
                {
                    schedule.IsConfirmed = true;
                    schedule.LastUpdatedAt = DateTime.Now;
                    return Ok(schedule);

                    //Creating and setting up the Schedule to be Attended


                    //var attended = new Attended
                    //{
                    //    SubjectId = schedule.SubjectId,
                    //    CreatedAt = DateTime.Now,
                    //    LastUpdatedAt =DateTime.Now                       
                    //}
                }

                schedule.IsConfirmed = false;
                schedule.LastUpdatedAt = DateTime.Now;

                return Ok(schedule);
            }
            return BadRequest(schedule);
        }
        */

        // PUT: api/Schedules/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSchedule([FromRoute] int id, [FromBody] Schedule schedule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != schedule.Id)
            {
                return BadRequest();
            }
            schedule.LastUpdatedAt = DateTime.Now;

            _context.Entry(schedule).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScheduleExists(id))
                {
                    return NotFound();
                }
                throw;
            }

            return NoContent();
        }

        // POST: api/Schedules
        [HttpPost]
        public async Task<IActionResult> PostSchedule([FromBody] Schedule schedule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            schedule.CreatedAt = DateTime.Now;
            schedule.LastUpdatedAt = DateTime.Now;

            _context.Schedules.Add(schedule);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSchedule", new { id = schedule.Id }, schedule);
        }

        // DELETE: api/Schedules/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSchedule([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var schedule = await _context.Schedules.SingleOrDefaultAsync(m => m.Id == id);
            if (schedule == null)
            {
                return NotFound();
            }

            schedule.IsDeleted = true;
            schedule.DeletedAt = DateTime.Now;

            await _context.SaveChangesAsync();

            return Ok(schedule);
        }

        private bool ScheduleExists(int id)
        {
            return _context.Schedules.Any(e => e.Id == id);
        }

        #endregion

        #region OPERATIONS FOR AUTHENTICATION

        [HttpGet("{id:int}/{confirm:bool}")]
        public IActionResult ConfirmSchedule(int id, [FromRoute] bool confirm)
        {
            if (confirm)
            {
                var schedule = _context.Schedules.Include(s => s.Subject).FirstOrDefault(s => s.Id == id);
                if (schedule == null)
                {
                    ModelState.AddModelError("Schedule", "Schedule with specified id was not found");
                    return BadRequest(ModelState);
                }

                schedule.IsConfirmed = true;
                schedule.LastUpdatedAt = DateTime.Now;

                _context.SaveChanges();

                return Ok();

                //Create an Attended instance

                //var students = _context.EnrolledSubjects.Include(es => es.Subject)
                //    .Include(es => es.Student)
                //    .Where(es => es.SubjectId == schedule.Subject.Id)
                //    .Select(es => es.Student).ToList();//.AsEnumerable();

                //var lecture = new Attended()
                //{
                //    Subject = schedule.Subject,
                //    SubjectId = schedule.Subject.Id,
                //    Students = students,
                //    CreatedAt = DateTime.Now,
                //    LastUpdatedAt = DateTime.Now
                //};

                //_context.Attendies.Add(lecture);
                //_context.SaveChanges();

                //return Ok();
            }

            return BadRequest();
        }

        [HttpGet("{studentId:int}/{scheduleId:int}")]
        public IActionResult RegisterStudent([FromRoute] int studentId, [FromRoute] int scheduleId)
        {
            try
            {
                var student = _context.Students.Include(s => s.EnrolledSubjects).FirstOrDefault(s => s.Id == studentId);

                if (student == null)
                    return BadRequest();

                var schedule = _context.Schedules.Include(s => s.Subject).FirstOrDefault(s => s.Id == scheduleId);
                if (schedule == null)
                    return BadRequest();

                var enrolled = student.EnrolledSubjects.FirstOrDefault(es => es.SubjectId == schedule.SubjectId);

                if (enrolled == null)
                    return BadRequest();

                var attended = new Attended()
                {
                    StudentId = studentId,
                    ScheduleId = scheduleId,
                    HasAttended = true,
                    CreatedAt = DateTime.Now,
                    LastUpdatedAt = DateTime.Now
                };

                _context.Attendies.Add(attended);
                _context.SaveChanges();

                return CreatedAtAction("GetSchedule", new { confirmed = false }, attended);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

            return BadRequest();
        }

        #endregion
    }
}