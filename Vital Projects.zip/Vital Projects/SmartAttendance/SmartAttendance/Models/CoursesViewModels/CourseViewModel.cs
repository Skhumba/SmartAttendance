﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Attendance.Domain;

namespace SmartAttendance.Models.CoursesViewModels
{
    public class CourseViewModel
    {
        public string Description { get; set; }
        public Course Course { get; set; }
        public IList<Announcement> Announcements { get; set; }
        public IList<Subject> Subjects { get; set; }     
    }
}
