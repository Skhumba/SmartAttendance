﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Attendance.Domain;

namespace SmartAttendance.Data.Service
{
    public interface IAttendanceService
    {
        Student AddStudent(Student student);
        Lecturer AddLecturer(Lecturer lecturer);
    }
}
